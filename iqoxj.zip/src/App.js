import React from "react";
import ReactDOM fromn"react-dom";
import app from"./components/app";

ReactDOM.render(
  <div>
    <App />
    </div>,
    document.getElementById("root")
);
